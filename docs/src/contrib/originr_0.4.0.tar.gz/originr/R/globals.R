if (getRversion() >= "2.15.1") {
  utils::globalVariables(c('nsr_countries','nsr_pol_divisions'))
}
