library("testthat")
test_check("originr")
