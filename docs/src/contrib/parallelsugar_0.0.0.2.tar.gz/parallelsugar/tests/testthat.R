library(testthat)
test_check("parallelsugar")

